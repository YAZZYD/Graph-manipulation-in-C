#ifndef header_h
#define header_h
extern int**MA;
void CreeMA(int** MA,unsigned int NumSommet);
void AfficheMA(int**MA,unsigned int NumSommet);
void Ajout_arrete(int**MA,int from,int to);
void Supp_arrete(int**MA,int from,int to);
void Ajout_Sommet(int**MA,int**New_MA,int NumSommet);
void Ordre_Graph(int NumSommet);
void Voisinage_Sommet(int **MA,int NumSommet,int Sommet);
void Deg_Sommet(int **MA,int Sommet);
int supp_Sommet(int**MA,int NumSommet,int sommet);
void permuterColonne(int**MA,int ligne,int i,int j);
void permuterLigne(int**MA,int i,int j);
void chemin_Euler(int **MA,int NumSommet);
void dessinArbre (int**MA, FILE* f, int NumSommet);

#endif
