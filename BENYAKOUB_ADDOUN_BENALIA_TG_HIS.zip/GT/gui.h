
#ifndef Interface_h
#define Interface_h
#include<time.h>
#include <stdlib.h>
#include<windows.h>
#include<conio.h>
#include"ExtraMethods.h"

//CET HEADER IMPLEMETN DES MOTHEDES CREE INITIALEMENT POUR FACILISER LE SWITVHING ENTRE LES DIFFERENTES ZONE
// DU PROGRAMME

void Loading(){

    CursorPosition(35,13);

    Color(14);

    printf("LOADING...");


    CursorPosition(20,15);

    Color(238);

    for(int i=0;i<=37;i++){

        printf("%c",177);

        Sleep(50);
    }
    Color(0);
}


//---------------------------------------------
void PressButtons(){
do{

            system("cls");

            CursorPosition(32,10);

            Color(14);

            puts("PRESS ANY KEY");

            Sleep(700);


            system("cls");

            Color(0);

            CursorPosition(32,10);

            puts("PRESS ANY KEY");

            Sleep(700);

}while(!kbhit());

system("cls");
}
//--------------------------------------------
 //IMAGE 01
void HIS(){
    Color(11);
CursorPosition(2,1);    printline(" _  _ ___ ___");
CursorPosition(2,2);   printline("| || |_ _/ __|");
CursorPosition(2,3);   printline("| __ || |\\_  \\");
CursorPosition(2,4);   printline("|_||_|___|___/");

}
    //IMAGE02
void ASD3(){
    Color(11);
CursorPosition(50,2);    printline("      2021/2022");
CursorPosition(50,3);    printline("DEPARTEMENT INFORMATIQUE");
CursorPosition(50,4);    printline("THEORIE DES GRAPHES");
CursorPosition(50,5);    printline("DR.BENALIA");
                      }

    //PRINTER IMAGE 01 && 02
void printline(char p[]){
int i=0;
while(p[i]!=NULL){ Sleep(15);
    printf("%c",p[i++]);

} printf("\n");
}

//---------------------------------------------
void OPSCREEN(){

    HIS();

    ASD3();

    Color(240);

    CursorPosition(10,7);

    TypeWritter(" GRAPHS THEORY-MINI PROJECT ");

    Color(176);

    CursorPosition(27,10);

    TypeWritter("CODED BY");

    Color(15);

    CursorPosition(20,13);

    printf(">> ");TypeWritter("BENYAKOUB ISLAM");

    CursorPosition(20,15);printf(">> ");

    TypeWritter("ADDOUN MOHAMED");

    CursorPosition(20,17);

    printf(">> ");TypeWritter("BENALIA YOUCEF");

}
//-------------///------------------------------///----------------------------//

void SwitchScreen(char *p){

    system("cls");

    puts("");Color(176);
    CursorPosition(26,2);
    printf(" %s ",p);

    Color(15);puts("");

}

////////--------------------------------------/-///////////-------------------------------/------//

void Menu(){
                system("cls");

                Color(48);
                puts("\n                                    MENU                                        ");
                Color(11);
                puts("\n   1>_CREATE ADJACENCY MATRIX");Sleep(200);
                puts("\n   2>_DISPLAY ADJACENCY MATRIX");Sleep(200);
                puts("\n   3>_ADD EDGE");Sleep(200);
                puts("\n   4>_DELETE EDGE");Sleep(200);
                puts("\n   5>_ADD VERTEX");Sleep(200);
                puts("\n   6>_DELETE VERTEX");Sleep(300);
                puts("\n   7>_DISPLAY NEIGHBORHOOD VERTICES");Sleep(200);
                puts("\n   8>_DISPLAY DEGREE OF VERETEX");Sleep(200);
                puts("\n   9>_DISPLAY GRAPH ORDER");Sleep(200);
                puts("\n   10>_SEARCH FOR EULERIAN PATH");Sleep(200);
                puts("\n   11>_PRINT GRAPH");Sleep(200);
                Color(224);
                puts("\n   0>_EXIT");Sleep(500);


                Color(15);
}
//---------///--//--------------------////-----------------///---------------------///------------------//
   void StaticMenu(){

    Color(48);
    puts("\n                                    MENU                                        ");
    Color(11);
                puts("\n   1>_CREATE ADJACENCY MATRIX");
                puts("\n   2>_DISPLAY ADJACENCY MATRIX");
                puts("\n   3>_ADD EDGE");
                puts("\n   4>_DELETE EDGE");
                puts("\n   5>_ADD VERTEX");
                puts("\n   6>_DELETE VERTEX");
                puts("\n   7>_DISPLAY NEIGHBORHOOD VERTICES");
                puts("\n   8>_DISPLAY DEGREE OF VERETEX");
                puts("\n   9>_DISPLAY GRAPH ORDER");
                puts("\n   10>_SEARCH FOR EULERIAN PATH");
                puts("\n   11>_PRINT GRAPH");
                Color(224);
                puts("\n   0>_EXIT");


                Color(15);
}

///---------------------------------------------////-------------------------------------------------////-----//

//--------------------------------------------------



#endif
