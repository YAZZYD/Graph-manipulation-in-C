#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<windows.h>
#include"header.h"
#include"gui.h"
void Check(int **MA){
    if(MA==NULL){
        system("cls");
        Color(12);
    CursorPosition(24,6);   TypeWritter(" ERROR !");
    CursorPosition(24,8);Color(192);  FastTypeWritter(" GRAPH EMPTY !");

    }}
void GotoMenu_div(){                            //PROCEDURE POUR DETECTER FRAPPE CLAVIER (ECHAPE BOUTTON)
                        CursorPosition(6,18);

                        Color(176); FastTypeWritter("PRESS ESC");Color(15);

                        int k;

                        do{
                                k = _getch();

                                if (k == 0 || k == 224) {

                                k = _getch();
                                                    }
                        }while(k!=27);

}

int main(){

int from,to;int keep=0;
int Choix;
int stop=0;
unsigned int NumSommet;
int **MA=NULL;
int **New_MA=NULL;
char cmd[100];
char nomf[50];
int sortie=1;
FILE *f;

OPSCREEN();
PressButtons();
Loading();  Sleep(500);


do{                 //FAIRE ... JUSQU'AU CHOIX CORRESPANDS A L'UN DES CHOIX

    Menu();
   do{
   system("cls");

    StaticMenu();       //AFFIHCER MENUE

    puts("");

   Color(62);

   FastTypeWritter("CHOOSE");Color(15);

   scanf("%d",&Choix);              // SCANNER CHOIX

    fflush(stdin);                  //NETTOYER TAMPON

   }while(!(Choix>=0 && Choix <=11));

    switch( Choix ){

                        case 1: SwitchScreen("CREATE ADJACENCY MATRIX");

                                CursorPosition(11,4);

                                Color(11);printf("NUMBER OF VERTICES:\t");Color(15);scanf("%u",&NumSommet);

                                fflush(stdin);

                                MA=(int**)calloc(NumSommet,sizeof(int*));

                                CreeMA(MA,NumSommet);

                                SwitchScreen("CREATE ADJACENCY MATRIX");

                                Color(11);CursorPosition(21,9);

                                FastTypeWritter("-MATRIX CREATED-");

                                Color(15);

                                GotoMenu_div();
                            break;

                         case 2: SwitchScreen("DISPLAY ADJACENCY MARTIX");

                                 Check(MA);

                                 if(MA!=NULL){

                                 Color(11);AfficheMA(MA,NumSommet);Color(15);}

                                 GotoMenu_div(); // ALLER VERS MENU

                             break;

                         case 3:  Check(MA);

                                  if(MA!=NULL){

                                  do{do{

                                    SwitchScreen("ADD NEW EDGE");

                                    CursorPosition(17,5);Color(48);

                                    FastTypeWritter("FROM:");from=_getch()-48;printf("%d\n",from);

                                   CursorPosition(17,8); FastTypeWritter("TO:");to=_getch()-48;printf("%d\n",to);Color(15);

                                    }while(from>NumSommet||to>NumSommet);

                                    Ajout_arrete(MA,from,to);
                                    CursorPosition(17,10);Color(11);FastTypeWritter("ADD ANOTHER EDGE ? (Y)");Color(15);
                                    keep=_getch();

                                    }while(keep==121);}

                                    GotoMenu_div();
                             break;

                        case 4:   Check(MA);

                                   if(MA!=NULL){

                                    do{do{

                                    SwitchScreen("DELETE EXISTING EDGE");

                                    CursorPosition(17,5);Color(48);

                                    FastTypeWritter("FROM:");from=_getch()-48;printf("%d\n",from);

                                   CursorPosition(17,8); FastTypeWritter("TO:");to=_getch()-48;printf("%d\n",to);Color(15);

                                            }while(from>NumSommet||to>NumSommet);

                                    Supp_arrete(MA,from,to);

                                    CursorPosition(17,10);Color(11);FastTypeWritter("ADD ANOTHER EDGE ? (Y)");Color(15);

                                    keep=_getch();

                                    }while(keep==121);}

                                GotoMenu_div();

                            break;

                        case 5: SwitchScreen("ADD NEW VERTREX");

                                int** New_MA=(int**)calloc((++NumSommet)*(NumSommet),sizeof(int));

                                Ajout_Sommet(MA,New_MA,NumSommet);

                                MA=(int**)calloc(NumSommet,sizeof(int*));

                                CreeMA(MA,NumSommet);

                                for(int i=0;i<NumSommet;i++){

                                for(int j=0;j<NumSommet;j++){

                                    MA[i][j]=New_MA[i][j];
                                     }
                                    }
                                Color(11);CursorPosition(21,9);

                                FastTypeWritter("-VERTEX ADDED-");

                                Color(15);

                                 GotoMenu_div();
                            break;

                      case 6: Check(MA);

                              if(MA!=NULL){

                              SwitchScreen("DELETE EXISTING VERTEX");

                              int To_delete;

                              CursorPosition(10,9);Color(48);

                              FastTypeWritter("VERTEX TO DELETE :");

                              To_delete=_getch()-48;printf("%d\n",to);Color(15);

                              NumSommet=supp_Sommet(MA,NumSommet,To_delete);

                              Color(11);CursorPosition(21,9);

                              FastTypeWritter("-VERTEX DELETED-");

                              Color(15);}

                            GotoMenu_div();
                        break;

                    case 7: Check(MA);

                            if(MA!=NULL){

                            SwitchScreen("DISPLAY NEIGHBORHOOD VERTICES");

                            int sommet;

                            CursorPosition(17,9);Color(48);

                            FastTypeWritter("VERTEX :");

                            sommet=_getch()-48;printf("%d\n",to);Color(15);

                            SwitchScreen("DISPLAY NEIGHBORHOOD VERTICES");

                            CursorPosition(12,9);Color(48);

                            FastTypeWritter(" NEIGHBOR VETRICES :");

                            Voisinage_Sommet(MA,NumSommet,sommet);
                                        }
                            GotoMenu_div();
                        break;

                    case 8: Check(MA);

                            if(MA!=NULL){

                            SwitchScreen("DISPLAY DEGREE OF VERTEX");

                            int sommet;

                            CursorPosition(17,9);Color(48);

                            FastTypeWritter("VERTEX :");

                            sommet=_getch()-48;printf("%d\n",to);Color(15);

                            SwitchScreen("DISPLAY DEGREE OF VERTEX");

                            CursorPosition(12,9);Color(48);

                            FastTypeWritter(" VERTEX DEGREE:");

                            Deg_Sommet(MA,sommet);}

                            GotoMenu_div();
                        break;
                case 9:     Check(MA);

                            if(MA!=NULL){

                            SwitchScreen("DISLAPY GRAPH ORDER");

                            CursorPosition(12,9);Color(48);

                            FastTypeWritter(" GRAPH ORDER:");

                            CursorPosition(45,9);Color(11);

                            printf("%d",NumSommet);}

                            GotoMenu_div();
                        break;
                case 10:    Check(MA);

                            if(MA!=NULL){

                            SwitchScreen("SEARCH FOR EULERIAN PATH");

                            CursorPosition(12,9);Color(48);

                            FastTypeWritter(" GRAPH ORDER:");

                            chemin_Euler(MA,NumSommet);}

                            GotoMenu_div();
                        break;

                case 11:Check(MA);

                        if(MA!=NULL){

                        SwitchScreen("PRINT NEW GRAPH");

                        sprintf(nomf, "Graph%d.dot", sortie);

                        f = fopen(nomf,"w");        // Ouverture du fichier en �criture.

                        fprintf(f, "graph arbre {\n");

                        fprintf(f, "\tordering = out;\n");

                        fprintf(f, "\tsplines = false;\n");

                        dessinArbre(MA, f, NumSommet);

                        fprintf(f, "}\n");

                        fclose(f);

                        sprintf(cmd, "cd .\Desktop\GT");

                        sprintf(cmd, "dot -Tpng Graph%d.dot -o Graph%d.png", sortie, sortie);

                        system(cmd);

                        Color(11);CursorPosition(21,9);

                        FastTypeWritter("-GRAPH  PRINTED-");

                        Color(15);

                        sprintf(cmd, "Graph%d.png", sortie);

                        system(cmd);}

                        GotoMenu_div();
                        break;
                case 0:     system("cls");

                            Color(11);CursorPosition(20,9);

                            FastTypeWritter("-PROGRAM TERMINATED-");

                            Color(15);

                            Sleep(500);

                            system("cls");

                            exit(0); // CAS D'EXIT
   }


 }while(!stop);


return 0;}


