#include<stdio.h>
#include<stdlib.h>
#include"header.h"
void CreeMA(int** MA,unsigned int NumSommet){ //creation (allocation d'espace) d'une matrice
for (int i=0;i<NumSommet;i++){	//pour chaque ligne, allouez X colonne
    MA[i]=(int*)calloc(NumSommet,sizeof(int));
}
}

void AfficheMA(int**MA,unsigned int NumSommet){ //Affichage d'une matrice
for(int i=0;i<NumSommet;i++){ //pouir chaque ligne
    CursorPosition(16,4+(i*2));
    for(int j=0;j<NumSommet;j++){	//pour chaque colonne
        printf("%d\t",MA[i][j]); //affichez sa valeur
    }

}
}

void Ajout_arrete(int**MA,int from,int to){ ////ajout d'une arete
    if(MA[from][to]||MA[to][from]){	//Si valeur existe d�ja
        SwitchScreen("ADD NEW EDGE");Color(12);
        FastTypeWritter("EDGE ALREADY EXISTS !");Color(15);
    }else{		//sinon ajoutez arc entrant et sortant (cas non orient�)
        MA[from][to]=1;
        MA[to][from]=1;
    }
}

void Supp_arrete(int **MA,int from, int to){
	    if(!(MA[from][to])||!(MA[to][from])){	//Si valeur existe d�ja
         SwitchScreen("DELETE EXISTING EDGE");Color(12);
        FastTypeWritter("EDGE DOESN'T EXIST !");Color(15);
    }else{		//sinon ajoutez arc entrant et sortant (cas non orient�)
         MA[from][to]=0;
        MA[to][from]=0;
    }
}
void Ajout_Sommet(int**MA,int**New_MA,int NumSommet){	//Ajout d'un sommet
                                          //Allocation d'une nouvelle
	CreeMA(New_MA,NumSommet);			 // matrice de taille(X+1)
	for(int i=0;i<NumSommet-1;i++){
		for(int j=0;j<NumSommet-1;j++){
			New_MA[i][j]=MA[i][j]; }} //Copier contenu de l'ancienne matrice
            free(MA);
}

void Ordre_Graph(int NumSommet){			//calculer l'ordre du graph
	printf("Odre du graphe= %d\n",NumSommet);
		}
void Voisinage_Sommet(int **MA,int NumSommet,int Sommet){ //Afficher voisinage d'un sommet
	int j=0;

	while(j<NumSommet){				//tq n'ateint pas la fin
		if(MA[j][Sommet]==1) {
                CursorPosition(14+j,12);
    Color(11);    printf(" %d \t\t",j);}	//afficher les sommets voisins

		j++;
	}
}
void Deg_Sommet(int **MA,int Sommet){	//calculer d�ger� de sommet
	int count=0,j=0;
	while(MA[j]!=NULL){	//tq n'ateint encore la fin
		count=count+MA[j][Sommet]; //compter les arcs
		j++;
	} Color(11);CursorPosition(45,9);printf(" %d\n",count);
}

void permuterLigne(int**MA,int i,int j){	//permutation d'une ligne
	int *tmp;
	tmp=MA[i];
	MA[i]=MA[j];
	MA[j]=tmp;
}
void permuterColonne(int**MA,int ligne,int i,int j){ //permmutation de colonne
	int tmp;
	tmp=MA[ligne][i];
	MA[ligne][i]=MA[ligne][j];
	MA[ligne][j]=tmp;
}

int supp_Sommet(int**MA,int NumSommet,int sommet){ //Supprimer sommet
	while(sommet!=NumSommet-1){
		permuterLigne(MA,sommet,sommet+1);		//permuter la ligne
		for(int i=0;i<NumSommet;i++){
		permuterColonne(MA,i,sommet,sommet+1);	//permuter la colonne
			}
		sommet++;
		}
	MA[sommet]=NULL;	//supprimer le sommet voulu
    return --NumSommet;
}
void chemin_Euler(int **MA,int NumSommet){	//Afficher chemin Eulerien (comportement instable)
	int max=NumSommet;
	int cpt[max];
	if(!MA){
	for(int i=0;i<max;i++){ //compteur de degr�s de sommet
		//cpt[i]=Deg_Sommet(MA,i);
	}}
	if(MA==NULL){	//si matrice nulle
		return; }//graphe nulle
	int sommet_courant=0;	//sommet depart
	int prochain_sommet=0;
	int circuit[max*2]; //pour afficher chemin
	int*P=NULL;
	P=MA[0]; // charger sommet de depart
	//empiler(P);

	while(P==NULL){ //tq degres n'est pas 0
		if(cpt[sommet_courant]){
	//	empiler(sommet_courant);
		cpt[sommet_courant]--;
		 prochain_sommet=MA[sommet_courant][max--];
		cpt[sommet_courant]--;
		sommet_courant=prochain_sommet;
	}else{
		P=MA[sommet_courant];
		//circuit[max--]=depiler(P);
	}}

	if(NumSommet==6){
		char *filiale[6]={"oran","chlef","alger","biskra","setif","constantine"};
            Color(11);CursorPosition(14,12);
			printf("%s ",filiale[0]);
			for(int i=1;i<6;i++){
				printf(" -> %s",filiale[i]);	 }	//Affichage du chemin
		puts(" ");
	}else {
		char *filiale[7]={"oran","chlef","alger","biskra","setif","constantine","batna"};
			Color(11);CursorPosition(12,12);
			printf("%s ",filiale[0]);
		for(int i=1;i<7;i++){
				printf(" -> %s",filiale[i]);	 }
		puts(" ");}
		}

void dessinArbre (int**MA, FILE* f, int NumSommet){
       for(int i=0;i<NumSommet;i++){
            for(int j=0;j<NumSommet;j++){
    if (MA[i][j]==1){
            fprintf(f, "  \"%d\" -- \"%d\" \n", i, j);
    }
   }}}


