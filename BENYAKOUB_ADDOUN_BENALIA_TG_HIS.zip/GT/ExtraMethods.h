
#ifndef EXTRAMETHODS_H
#define EXTRAMETHODS_H


//CET HEADER CONTIENT DE METHODES CREER AU BUT DE FACILITER LA LECTURE DU CODE
//EN MEME TEMPS CES METHODES AIDENT A MINIMIZER LE TANT DE CODE

//---------------------------//--------///-------------///----------

void Color(int x){      // COULEUR DU TEEXT

SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),x);
}

//--------------------------------------//---------///-----------
void CursorPosition(int x,int y){       // POSITION DU CUSREUR
    COORD pos;
    pos.X=x;
    pos.Y=y;

SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}

//------------------------////--------------------------------///------------------///
void TypeWritter(char *p){      // EFFET D'AFFICHAGE ( DESIGN IHM )

    if(*p==NULL){

        return;
    }
    while(*p){

        printf("%c \xDB",*p++);

        Sleep(40);

        printf("\b \b");

        Sleep(70);   }

        Sleep(300);
}
//------------------------////--------------------------------///------------------///
void FastTypeWritter(char *p){ // TYPEWITER MAIS EFFET PLUS RAPIDE

    if(*p==NULL){

        return;
    }
    while(*p){

        printf("%c \xDB",*p++);

        Sleep(10);

        printf("\b \b");

        Sleep(35);   }

        Sleep(300);
}

//-----------------------///-------------------------------////--------//-----



#endif // EXTRAMETHODS_H
